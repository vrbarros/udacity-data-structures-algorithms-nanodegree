For this problem, recursion is a good approach because the tree structure with which the check needs to occur can have a random depth.

Considering the time complexity O(n) for the loops inside the is_user_in_group().