The solution for Blockchain class use a LinkedList approach to handle each block from the blockchain.

Time and space complexity for add_block is O(1), once that happens in a constant time with a single variable.

